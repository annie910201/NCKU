# ATCONV Verification

## Requirements
- Python 3.7.7
- opencv-python==4.7.0.72

## Usage 
- ` pip install opencv-python`
- `$ python main.py`

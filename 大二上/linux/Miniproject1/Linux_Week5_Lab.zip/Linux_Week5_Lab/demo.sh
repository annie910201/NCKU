while read line     
do
        id=$( find /home/annie/Downloads/Linux_Week5_Lab/compressed_files -name ${line}.zip -o -name ${line}.rar -o -name ${line}.tar.gz -o -name ${line}.dika )
        if [ -z ${id} ]; then
                echo ${line} >> /home/annie/Downloads/Linux_Week5_Lab/missing_list.txt
        fi

        wrong=$( find /home/annie/Downloads/Linux_Week5_Lab/compressed_files -name ${line}.dika )
        if [ ! -z ${wrong} ]; then
                echo ${line} >> /home/annie/Downloads/Linux_Week5_Lab/wrong_list.txt
                mv ${wrong} /home/annie/Downloads/Linux_Week5_Lab/compressed_files/unknown/
        fi

        zz=$( find /home/annie/Downloads/Linux_Week5_Lab/compressed_files -name ${line}.zip )
        if [ ! -z ${zz} ]; then 
                mv ${zz} /home/annie/Downloads/Linux_Week5_Lab/compressed_files/zip/
        fi
        
        rr=$( find /home/annie/Downloads/Linux_Week5_Lab/compressed_files -name ${line}.rar )
        if [ ! -z ${rr} ]; then
                mv ${rr} /home/annie/Downloads/Linux_Week5_Lab/compressed_files/rar/
        fi

        tt=$( find /home/annie/Downloads/Linux_Week5_Lab/compressed_files -name ${line}.tar.gz )
        if [ ! -z ${tt} ]; then
                mv ${tt} /home/annie/Downloads/Linux_Week5_Lab/compressed_files/tar.gz/
        fi
done < student_id
